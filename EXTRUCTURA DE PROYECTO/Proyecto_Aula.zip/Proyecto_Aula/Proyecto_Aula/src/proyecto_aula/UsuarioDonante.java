package proyecto_aula;

import java.io.Serializable;
import java.util.ArrayList;

public class UsuarioDonante implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String usuario;
    private final String contrasena;
    private final String tiposangre;
    private final String nombre;
    private final int id;
    private final int celular;
    private final String correo;
    private final ArrayList<String> citas;

    public UsuarioDonante(String usuario, String contrasena, String tiposangre, String nombre, int id, int celular, String correo) {
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.tiposangre = tiposangre;
        this.nombre = nombre;
        this.id = id;
        this.celular = celular;
        this.correo = correo;
        this.citas = new ArrayList<>();
    }

    public String getUsuario() {
        return usuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public String getTiposangre() {
        return tiposangre;
    }

    public String getNombre() {
        return nombre;
    }

    public int getId() {
        return id;
    }

    public int getCelular() {
        return celular;
    }

    public String getCorreo() {
        return correo;
    }

    public ArrayList<String> getCitas() {
        return citas;
    }

    public void agendarCita(String cita) {
        citas.add(cita);
    }

    public boolean cancelarCita(String cita) {
        return citas.remove(cita);
    }
}
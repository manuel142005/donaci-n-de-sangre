package proyecto_aula;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Proyecto_Aula {
    static ArrayList<UsuarioDonante> donantes = new ArrayList<>();
    static HashMap<String, Integer> bancoSangre = new HashMap<>();
    static ArrayList<String> historialCambiosSangre = new ArrayList<>();
    static final String MED_USER = "medico";
    static final String MED_PASS = "1234";
    static final String ADMIN_USER = "admin";
    static final String ADMIN_PASS = "admin";
    static final String BANCO_USER = "banco";
    static final String BANCO_PASS = "1234";

        public static void main(String[] args) {
        // Cargar datos de donantes desde el archivo al iniciar
        donantes = GestorDonantes.cargarDonantesTxt();

        // Asegurarse de guardar los datos al cerrar la aplicación
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            GestorDonantes.guardarDonantesTxt(donantes);
            System.out.println("Datos guardados correctamente en donantes.txt.");
        }));
        // Estilos personalizados para los botones
        UIManager.put("Button.font", new Font("Arial", Font.BOLD, 16));
        UIManager.put("Button.background", new Color(70, 130, 180));
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.border", BorderFactory.createEmptyBorder());
        
        JFrame frame = new JFrame("Donate Blood");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        frame.getContentPane().setBackground(new Color(245, 245, 245));
        
        JLabel titleLabel = new JLabel("Binevenido a Donate Blood", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        frame.add(titleLabel);

        JButton btnRegistrarDonante = new JButton("Registro Donante");
        JButton btnLoginDonante = new JButton("Iniciar Sesión Donante");
        JButton btnCentroMedico = new JButton("Centro Médico");
        JButton btnBancoSangre = new JButton("Banco de Sangre");
        JButton btnAdmin = new JButton("Administrador");
        JButton btnFinalizar = new JButton("Finalizar");

        for (JButton b : new JButton[]{btnRegistrarDonante, btnLoginDonante, btnCentroMedico, btnBancoSangre, btnAdmin, btnFinalizar}) {
            b.setMaximumSize(new Dimension(300, 50));
            b.setAlignmentX(Component.CENTER_ALIGNMENT);
            b.setFocusPainted(false); // Elimina el borde de foco al presionar
            b.setCursor(new Cursor(Cursor.HAND_CURSOR)); // Cambia el cursor al pasar por encima
            frame.add(Box.createVerticalStrut(10));
            frame.add(b);
        }

        btnRegistrarDonante.addActionListener(e -> mostrarRequisitosAntesDeRegistrar());
        btnLoginDonante.addActionListener(e -> loginDonante());
        btnCentroMedico.addActionListener(e -> {
            if (login(MED_USER, MED_PASS)) {
                mostrarPanelCentroMedico();
            }
        });
        btnBancoSangre.addActionListener(e -> {
            if (login(BANCO_USER, BANCO_PASS)) {
                mostrarPanelBancoSangre();
            }
        });
        btnAdmin.addActionListener(e -> {
            if (login(ADMIN_USER, ADMIN_PASS)) {
                mostrarPanelAdministrador();
            }
        });
        btnFinalizar.addActionListener(e -> System.exit(0));

        frame.setVisible(true);
    }

    private static void mostrarRequisitosAntesDeRegistrar() {
        String requisitos = """
            Requisitos para donar sangre:
            - Tener entre 18 y 65 años.
            - Pesar más de 50 kg.
            - Estar en buen estado de salud.
            - No haber donado sangre en los últimos 2 meses.
            - No estar embarazada.
            - No haber consumido alcohol en las últimas 24 horas.
            - No padecer enfermedades de transmisión sanguínea.
        """;

        int respuesta = JOptionPane.showConfirmDialog(null,
                "¿Desea ver los requisitos para donar sangre antes de registrarse?",
                "Requisitos para Donar Sangre",
                JOptionPane.YES_NO_OPTION);

        if (respuesta == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, requisitos, "Requisitos para Donar Sangre", JOptionPane.INFORMATION_MESSAGE);
        }

        registrarDonante();
    }

    private static void registrarDonante() {
        JTextField nombre = new JTextField();
        JTextField id = new JTextField();
        JTextField cel = new JTextField();
        JTextField correo = new JTextField();
        JTextField tipoSangre = new JTextField();
        JTextField usuarioF = new JTextField();
        JPasswordField passF = new JPasswordField();

        Object[] campos = {
            "Nombre:", nombre, "ID:", id, "Celular:", cel,
            "Correo:", correo, "Tipo de sangre:", tipoSangre,
            "Usuario:", usuarioF, "Contraseña:", passF
        };

        int result = JOptionPane.showConfirmDialog(null, campos, "Registro Donante", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                int idInt = Integer.parseInt(id.getText());
                int celInt = Integer.parseInt(cel.getText());
                UsuarioDonante d = new UsuarioDonante(usuarioF.getText(), new String(passF.getPassword()), tipoSangre.getText(), nombre.getText(), idInt, celInt, correo.getText());
                donantes.add(d);
                JOptionPane.showMessageDialog(null, "Donante registrado con éxito.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "ID y celular deben ser números.");
            }
        }
    }

    private static void loginDonante() {
        String usuario = JOptionPane.showInputDialog("Usuario:");
        String contrasena = JOptionPane.showInputDialog("Contraseña:");
        for (UsuarioDonante d : donantes) {
            if (d.getUsuario().equals(usuario) && d.getContrasena().equals(contrasena)) {
                mostrarPanelDonante(d);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Credenciales incorrectas.");
    }

    private static void mostrarPanelDonante(UsuarioDonante ud) {
        JFrame donanteFrame = new JFrame("Panel Donante");
        donanteFrame.setSize(300, 200);
        donanteFrame.setLayout(new GridLayout(3, 1));
        donanteFrame.setLocationRelativeTo(null);

        JButton btnAgendar = new JButton("Agendar Cita");
        JButton btnCancelar = new JButton("Cancelar Cita");
        JButton btnVerCitas = new JButton("Ver Citas");

        btnAgendar.addActionListener(a -> {
            String cita = JOptionPane.showInputDialog("Ingrese fecha y hora:");
            if (cita != null && !cita.isBlank()) {
                ud.agendarCita(cita);
                JOptionPane.showMessageDialog(null, "Cita agendada.");
            }
        });

        btnCancelar.addActionListener(c -> {
            String cita = JOptionPane.showInputDialog("Cita a cancelar:");
            if (ud.cancelarCita(cita)) {
                JOptionPane.showMessageDialog(null, "Cita cancelada.");
            } else {
                JOptionPane.showMessageDialog(null, "Cita no encontrada.");
            }
        });

        btnVerCitas.addActionListener(v -> {
            if (ud.getCitas().isEmpty()) {
                JOptionPane.showMessageDialog(null, "No tienes citas agendadas.");
            } else {
                StringBuilder sb = new StringBuilder("Tus citas:\n");
                for (String cita : ud.getCitas()) {
                    sb.append("- ").append(cita).append("\n");
                }
                JOptionPane.showMessageDialog(null, sb.toString());
            }
        });

        donanteFrame.add(btnAgendar);
        donanteFrame.add(btnCancelar);
        donanteFrame.add(btnVerCitas);
        donanteFrame.setVisible(true);
    }

    private static boolean login(String userCorrecto, String passCorrecta) {
        JTextField usuario = new JTextField();
        JPasswordField pass = new JPasswordField();
        Object[] campos = {"Usuario:", usuario, "Contraseña:", pass};
        int result = JOptionPane.showConfirmDialog(null, campos, "Inicio de Sesión", JOptionPane.OK_CANCEL_OPTION);
        return result == JOptionPane.OK_OPTION &&
               userCorrecto.equals(usuario.getText()) &&
               passCorrecta.equals(new String(pass.getPassword()));
    }

    private static void mostrarPanelCentroMedico() {
        JFrame medicoFrame = new JFrame("Panel Centro Médico");
        medicoFrame.setSize(300, 300);
        medicoFrame.setLayout(new GridLayout(2, 1));

        JButton btnConsultarSangre = new JButton("Consultar Unidades de Sangre");
        JButton btnSolicitarSangre = new JButton("Hacer Encargo de Sangre");

        btnConsultarSangre.addActionListener(v -> {
            if (bancoSangre.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No hay unidades de sangre registradas.");
            } else {
                StringBuilder sb = new StringBuilder("Unidades de sangre disponibles:\n");
                for (String tipo : bancoSangre.keySet()) {
                    sb.append(tipo).append(": ").append(bancoSangre.get(tipo)).append(" unidades\n");
                }
                JOptionPane.showMessageDialog(null, sb.toString());
            }
        });

        btnSolicitarSangre.addActionListener(v -> {
            JTextField tipoSangre = new JTextField();
            JTextField cantidad = new JTextField();

            Object[] campos = {
                "Tipo de sangre (ej. A+, O-):", tipoSangre,
                "Cantidad solicitada:", cantidad
            };

            int result = JOptionPane.showConfirmDialog(null, campos, "Encargar Unidades de Sangre", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                try {
                    String tipo = tipoSangre.getText().toUpperCase();
                    int cantidadSolicitada = Integer.parseInt(cantidad.getText());

                    if (!bancoSangre.containsKey(tipo) || bancoSangre.get(tipo) < cantidadSolicitada) {
                        JOptionPane.showMessageDialog(null, "No hay suficientes unidades de sangre del tipo " + tipo + ".");
                    } else {
                        bancoSangre.put(tipo, bancoSangre.get(tipo) - cantidadSolicitada);
                        JOptionPane.showMessageDialog(null, "Encargo realizado con éxito. Se han entregado " + cantidadSolicitada + " unidades de sangre tipo " + tipo + ".");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "La cantidad debe ser un número entero.");
                }
            }
        });

        medicoFrame.add(btnConsultarSangre);
        medicoFrame.add(btnSolicitarSangre);
        medicoFrame.setVisible(true);
    }

    private static void mostrarPanelBancoSangre() {
        JFrame bancoFrame = new JFrame("Panel Banco de Sangre");
        bancoFrame.setSize(400, 300);
        bancoFrame.setLayout(new GridLayout(3, 1));

        JButton btnVerDonantes = new JButton("Ver Donantes");
        JButton btnVerSangre = new JButton("Ver Unidades de Sangre");
        JButton btnModificarSangre = new JButton("Modificar Unidades");

        btnVerDonantes.addActionListener(v -> {
            if (donantes.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No hay donantes registrados.");
            } else {
                StringBuilder sb = new StringBuilder("Donantes registrados:\n");
                for (UsuarioDonante d : donantes) {
                    sb.append("- ").append(d.getNombre())
                            .append(" | ID: ").append(d.getId())
                            .append(" | Tipo de sangre: ").append(d.getTiposangre()).append("\n");
                }
                JOptionPane.showMessageDialog(null, sb.toString());
            }
            
        });
        

        btnVerSangre.addActionListener(v -> {
            if (bancoSangre.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No hay unidades de sangre registradas.");
            } else {
                StringBuilder sb = new StringBuilder("Unidades de sangre disponibles:\n");
                for (String tipo : bancoSangre.keySet()) {
                    sb.append(tipo).append(": ").append(bancoSangre.get(tipo)).append(" unidades\n");
                }
                JOptionPane.showMessageDialog(null, sb.toString());
            }
        });

        btnModificarSangre.addActionListener(v -> {
            JTextField tipoSangre = new JTextField();
            JTextField cantidad = new JTextField();

            Object[] campos = {
                "Tipo de sangre (ej. A+, O-):", tipoSangre,
                "Cantidad (número entero):", cantidad
            };

            int result = JOptionPane.showConfirmDialog(null, campos, "Modificar Unidades de Sangre", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                try {
                    String tipo = tipoSangre.getText().toUpperCase();
                    int cantidadNueva = Integer.parseInt(cantidad.getText());
                    if (cantidadNueva < 0) {
                        JOptionPane.showMessageDialog(null, "No se pueden tener cantidades negativas.");
                    } else {
                        bancoSangre.put(tipo, cantidadNueva);
                        JOptionPane.showMessageDialog(null, "Unidades de sangre actualizadas.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "La cantidad debe ser un número entero.");
                }
            }
        });

        bancoFrame.add(btnVerDonantes);
        bancoFrame.add(btnVerSangre);
        bancoFrame.add(btnModificarSangre);
        bancoFrame.setVisible(true);
    }

    private static void mostrarPanelAdministrador() {
        JFrame adminFrame = new JFrame("Panel Administrador");
        adminFrame.setSize(400, 500);
        adminFrame.setLayout(new GridLayout(5, 1));

        JButton btnGestionarDonantes = new JButton("Gestionar Donantes");
        JButton btnGestionarCitas = new JButton("Gestionar Citas");
        JButton btnGestionarUnidadesSangre = new JButton("Gestionar Unidades de Sangre");
        JButton btnVerHistorial = new JButton("Ver Historial de Cambios");
        JButton btnCrearEliminarCitas = new JButton("Crear/Eliminar Citas");

        btnGestionarDonantes.addActionListener(e -> gestionarDonantes());
        btnGestionarCitas.addActionListener(e -> gestionarCitas());
        btnGestionarUnidadesSangre.addActionListener(e -> gestionarUnidadesSangre());
        btnVerHistorial.addActionListener(e -> mostrarHistorialCambios());
        btnCrearEliminarCitas.addActionListener(e -> crearEliminarCitasAdministrador());

        adminFrame.add(btnGestionarDonantes);
        adminFrame.add(btnGestionarCitas);
        adminFrame.add(btnGestionarUnidadesSangre);
        adminFrame.add(btnVerHistorial);
        adminFrame.add(btnCrearEliminarCitas);
        adminFrame.setVisible(true);
    }

    private static void gestionarDonantes() {
        String[] opciones = {"Agregar Donante", "Eliminar Donante", "Cancelar"};
        int seleccion = JOptionPane.showOptionDialog(null, "Seleccione una acción", "Gestionar Donantes",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

        if (seleccion == 0) {
            registrarDonante();
        } else if (seleccion == 1) {
            eliminarDonante();
        }
    }

    private static void eliminarDonante() {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del donante a eliminar:");
        if (nombre != null) {
            boolean eliminado = donantes.removeIf(d -> d.getNombre().equalsIgnoreCase(nombre));
            if (eliminado) {
                JOptionPane.showMessageDialog(null, "Donante eliminado con éxito.");
            } else {
                JOptionPane.showMessageDialog(null, "Donante no encontrado.");
            }
        }
    }

    private static void gestionarCitas() {
        StringBuilder sb = new StringBuilder("Citas programadas:\n");
        boolean hayCitas = false;
        for (UsuarioDonante ud : donantes) {
            if (!ud.getCitas().isEmpty()) {
                sb.append("Donante: ").append(ud.getNombre()).append("\n");
                for (String cita : ud.getCitas()) {
                    sb.append("  - ").append(cita).append("\n");
                }
                hayCitas = true;
            }
        }
        if (!hayCitas) {
            sb.append("No hay citas programadas.");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void gestionarUnidadesSangre() {
        JFrame sangreFrame = new JFrame("Gestionar Unidades de Sangre");
        sangreFrame.setSize(400, 300);
        sangreFrame.setLayout(new GridLayout(3, 1));

        JButton btnAgregar = new JButton("Agregar Unidades");
        JButton btnModificar = new JButton("Modificar Unidades");
        JButton btnEliminar = new JButton("Eliminar Unidades");

        btnAgregar.addActionListener(e -> agregarUnidadesSangre());
        btnModificar.addActionListener(e -> modificarUnidadesSangre());
        btnEliminar.addActionListener(e -> eliminarUnidadesSangre());

        sangreFrame.add(btnAgregar);
        sangreFrame.add(btnModificar);
        sangreFrame.add(btnEliminar);
        sangreFrame.setVisible(true);
    }

    private static void agregarUnidadesSangre() {
        JTextField tipoSangre = new JTextField();
        JTextField cantidad = new JTextField();

        Object[] campos = {
            "Tipo de sangre (ej. A+, O-):", tipoSangre,
            "Cantidad a agregar:", cantidad
        };

        int result = JOptionPane.showConfirmDialog(null, campos, "Agregar Unidades de Sangre", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String tipo = tipoSangre.getText().toUpperCase();
                int cantidadAgregar = Integer.parseInt(cantidad.getText());
                if (cantidadAgregar < 0) {
                    JOptionPane.showMessageDialog(null, "No se pueden agregar cantidades negativas.");
                } else {
                    int cantidadAnterior = bancoSangre.getOrDefault(tipo, 0);
                    bancoSangre.put(tipo, cantidadAnterior + cantidadAgregar);
                    historialCambiosSangre.add("Agregado: " + tipo + " + " + cantidadAgregar + " unidades");
                    JOptionPane.showMessageDialog(null, "Unidades de sangre agregadas.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "La cantidad debe ser un número entero.");
            }
        }
    }

    private static void modificarUnidadesSangre() {
        JTextField tipoSangre = new JTextField();
        JTextField cantidad = new JTextField();

        Object[] campos = {
            "Tipo de sangre (ej. A+, O-):", tipoSangre,
            "Nueva cantidad:", cantidad
        };

        int result = JOptionPane.showConfirmDialog(null, campos, "Modificar Unidades de Sangre", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String tipo = tipoSangre.getText().toUpperCase();
                int nuevaCantidad = Integer.parseInt(cantidad.getText());
                if (nuevaCantidad < 0) {
                    JOptionPane.showMessageDialog(null, "No se pueden establecer cantidades negativas.");
                } else {
                    int cantidadAnterior = bancoSangre.getOrDefault(tipo, 0);
                    bancoSangre.put(tipo, nuevaCantidad);
                    historialCambiosSangre.add("Modificado: " + tipo + " de " + cantidadAnterior + " a " + nuevaCantidad + " unidades");
                    JOptionPane.showMessageDialog(null, "Unidades de sangre modificadas.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "La cantidad debe ser un número entero.");
            }
        }
    }

    private static void eliminarUnidadesSangre() {
        JTextField tipoSangre = new JTextField();
        JTextField cantidad = new JTextField();

        Object[] campos = {
            "Tipo de sangre (ej. A+, O-):", tipoSangre,
            "Cantidad a eliminar:", cantidad
        };

        int result = JOptionPane.showConfirmDialog(null, campos, "Eliminar Unidades de Sangre", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String tipo = tipoSangre.getText().toUpperCase();
                int cantidadEliminar = Integer.parseInt(cantidad.getText());
                if (cantidadEliminar < 0 || !bancoSangre.containsKey(tipo) || bancoSangre.get(tipo) < cantidadEliminar) {
                    JOptionPane.showMessageDialog(null, "No se pueden eliminar unidades negativas o más unidades de las disponibles.");
                } else {
                    int cantidadAnterior = bancoSangre.get(tipo);
                    bancoSangre.put(tipo, cantidadAnterior - cantidadEliminar);
                    historialCambiosSangre.add("Eliminado: " + tipo + " - " + cantidadEliminar + " unidades");
                    JOptionPane.showMessageDialog(null, "Unidades de sangre eliminadas.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "La cantidad debe ser un número entero.");
            }
        }
    }

    private static void mostrarHistorialCambios() {
        if (historialCambiosSangre.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay cambios registrados.");
        } else {
            StringBuilder sb = new StringBuilder("Historial de Cambios:\n");
            for (String cambio : historialCambiosSangre) {
                sb.append(cambio).append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }

    private static void crearEliminarCitasAdministrador() {
        String[] opciones = {"Crear Cita", "Eliminar Cita", "Cancelar"};
        int seleccion = JOptionPane.showOptionDialog(null, "Seleccione una acción", "Gestionar Citas (Admin)",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

        if (seleccion == 0) {
            crearCitaAdmin();
        } else if (seleccion == 1) {
            eliminarCitaAdmin();
        }
    }

    private static void crearCitaAdmin() {
        String donanteNombre = JOptionPane.showInputDialog("Ingrese el nombre del donante para crear una cita:");
        for (UsuarioDonante donante : donantes) {
            if (donante.getNombre().equalsIgnoreCase(donanteNombre)) {
                String cita = JOptionPane.showInputDialog("Ingrese fecha y hora de la cita:");
                if (cita != null && !cita.isBlank()) {
                    donante.agendarCita(cita);
                    JOptionPane.showMessageDialog(null, "Cita creada con éxito para el donante: " + donanteNombre);
                }
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Donante no encontrado.");
    }

    private static void eliminarCitaAdmin() {
        String donanteNombre = JOptionPane.showInputDialog("Ingrese el nombre del donante para eliminar una cita:");
        for (UsuarioDonante donante : donantes) {
            if (donante.getNombre().equalsIgnoreCase(donanteNombre)) {
                String cita = JOptionPane.showInputDialog("Ingrese fecha y hora de la cita a eliminar:");
                if (donante.cancelarCita(cita)) {
                    JOptionPane.showMessageDialog(null, "Cita eliminada con éxito para el donante: " + donanteNombre);
                } else {
                    JOptionPane.showMessageDialog(null, "Cita no encontrada.");
                }
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Donante no encontrado.");
    }
}

package proyecto_aula;

public class Hospital extends CentroMedico {
    public Hospital(String direccion, String nombre, int telefono) {
        super(direccion, nombre, telefono);
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Hospital: " + nombre);
        System.out.println("Dirección: " + direccion);
        System.out.println("Teléfono: " + telefono);
    }
}

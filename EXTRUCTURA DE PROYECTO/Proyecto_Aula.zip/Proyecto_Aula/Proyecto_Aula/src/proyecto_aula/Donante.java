package proyecto_aula;

import java.util.ArrayList;

public abstract class Donante {
    protected String nombre;
    protected int id;
    protected int cel;
    protected String correo;
    protected String tiposangre;
    protected ArrayList<String> citas = new ArrayList<>();

    public Donante(String nombre, int id, int cel, String correo, String tiposangre) {
        this.nombre = nombre;
        this.id = id;
        this.cel = cel;
        this.correo = correo;
        this.tiposangre = tiposangre;
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getId() { return id; }
    public int getCel() { return cel; }
    public void setCel(int cel) { this.cel = cel; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getTiposangre() { return tiposangre; }
    public void setTiposangre(String tiposangre) { this.tiposangre = tiposangre; }

    public ArrayList<String> getCitas() { return citas; }

    public void agendarCita(String cita) {
        citas.add(cita);
    }

    public boolean cancelarCita(String cita) {
        return citas.remove(cita);
    }
}

package proyecto_aula;

import java.io.*;
import java.util.ArrayList;

public class GestorDonantes {
    private static final String ARCHIVO_BINARIO = "donantes.dat";
    private static final String ARCHIVO_TXT = "donantes.txt";

    // Guarda los donantes en un archivo binario
    public static void guardarDonantes(ArrayList<UsuarioDonante> lista) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_BINARIO))) {
            oos.writeObject(lista);
        } catch (IOException e) {
            System.out.println("Error al guardar donantes: " + e.getMessage());
        }
    }

    // Carga los donantes desde un archivo binario
    public static ArrayList<UsuarioDonante> cargarDonantes() {
        File archivo = new File(ARCHIVO_BINARIO);
        if (!archivo.exists()) return new ArrayList<>();

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            return (ArrayList<UsuarioDonante>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar donantes: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    // Guarda los donantes en un archivo de texto
    public static void guardarDonantesTxt(ArrayList<UsuarioDonante> lista) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO_TXT))) {
            for (UsuarioDonante donante : lista) {
                writer.write(donante.getNombre() + "," +
                        donante.getId() + "," +
                        donante.getCelular() + "," +
                        donante.getCorreo() + "," +
                        donante.getTiposangre() + "," +
                        donante.getUsuario() + "," +
                        donante.getContrasena());
                writer.newLine();
                for (String cita : donante.getCitas()) {
                    writer.write("CITA:" + cita);
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            System.out.println("Error al guardar donantes en TXT: " + e.getMessage());
        }
    }

    // Carga los donantes desde un archivo de texto
    public static ArrayList<UsuarioDonante> cargarDonantesTxt() {
        ArrayList<UsuarioDonante> lista = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO_TXT))) {
            String linea;
            UsuarioDonante donante = null;
            while ((linea = reader.readLine()) != null) {
                if (linea.startsWith("CITA:")) {
                    if (donante != null) {
                        donante.agendarCita(linea.substring(5)); // Agrega la cita al último donante leído
                    }
                } else {
                    String[] datos = linea.split(",");
                    if (datos.length == 7) {
                        donante = new UsuarioDonante(
                                datos[5], // usuario
                                datos[6], // contraseña
                                datos[4], // tipo de sangre
                                datos[0], // nombre
                                Integer.parseInt(datos[1]), // id
                                Integer.parseInt(datos[2]), // celular
                                datos[3]); // correo
                        lista.add(donante);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar donantes desde TXT: " + e.getMessage());
        }
        return lista;
    }
}
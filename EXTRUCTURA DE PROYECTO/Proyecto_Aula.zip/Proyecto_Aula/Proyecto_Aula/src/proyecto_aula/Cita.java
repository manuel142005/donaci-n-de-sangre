package proyecto_aula;

import java.time.LocalDate;

public class Cita {
    private LocalDate fecha;
    private String lugar;

    public Cita(LocalDate fecha, String lugar) {
        this.fecha = fecha;
        this.lugar = lugar;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    @Override
    public String toString() {
        return "Fecha: " + fecha + " - Lugar: " + lugar;
    }
}
